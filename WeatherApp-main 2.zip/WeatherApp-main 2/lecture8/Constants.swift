//
//  Constants.swift
//  lecture8
//
//  Created by Ashim Dauren on 09.02.2021.
//

import Foundation

struct Constants {
    static let hostNurSultan = "https://api.openweathermap.org/data/2.5/onecall?lat=51.1801&lon=71.446&exclude=minutely,alerts&appid=0e9477e67e53c8c91844f7d87860ae02&units=metric"
    
    static let hostAlmaty = "https://api.openweathermap.org/data/2.5/onecall?lat=43.25654&lon=76.92848&exclude=minutely,alerts&appid=0e9477e67e53c8c91844f7d87860ae02&units=metric"
    
    static let hostNewYork =
        "https://api.openweathermap.org/data/2.5/onecall?lat=42.35843&lon=-71.05977&exclude=minutely,alerts&appid=0e9477e67e53c8c91844f7d87860ae02&units=metric"
    
//    static let city = "Astana"
//    static let apiKey = "0e9477e67e53c8c91844f7d87860ae02"
}
